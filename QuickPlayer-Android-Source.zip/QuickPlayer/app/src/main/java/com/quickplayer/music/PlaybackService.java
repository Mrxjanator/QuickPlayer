package com.quickplayer.music;

import android.app.*;
import android.content.*;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import java.util.ArrayList;
import java.io.IOException;

public class PlaybackService extends Service {
    public static final String ACTION_PLAY="qp.PLAY", ACTION_TOGGLE="qp.TOGGLE", ACTION_NEXT="qp.NEXT", ACTION_PREVIOUS="qp.PREV", ACTION_SHUFFLE="qp.SHUFFLE";
    public static final String EXTRA_URIS="uris", EXTRA_TITLES="titles", EXTRA_ARTISTS="artists", EXTRA_INDEX="index";
    private static final String CHANNEL="quick_player_playback";
    private ArrayList<String> uris=new ArrayList<>(), titles=new ArrayList<>(), artists=new ArrayList<>();
    private int index=0; private MediaPlayer player; private boolean prepared=false, shuffle=false;

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent == null) return START_STICKY;
        String action=intent.getAction();
        if (ACTION_PLAY.equals(action) || ACTION_SHUFFLE.equals(action)) {
            ArrayList<String> u=intent.getStringArrayListExtra(EXTRA_URIS);
            if (u!=null) { uris=u; titles=intent.getStringArrayListExtra(EXTRA_TITLES); artists=intent.getStringArrayListExtra(EXTRA_ARTISTS); index=intent.getIntExtra(EXTRA_INDEX,0); }
            shuffle=ACTION_SHUFFLE.equals(action);
            playCurrent();
        } else if (ACTION_TOGGLE.equals(action)) {
            if (player==null) playCurrent(); else if (player.isPlaying()) { player.pause(); updateNotification(); } else { if(prepared) player.start(); else playCurrent(); updateNotification(); }
        } else if (ACTION_NEXT.equals(action)) next();
        else if (ACTION_PREVIOUS.equals(action)) previous();
        return START_STICKY;
    }
    private void playCurrent() {
        if (uris.isEmpty()) { stopSelf(); return; }
        if (index<0 || index>=uris.size()) index=0;
        releasePlayer();
        try {
            player=new MediaPlayer(); player.setDataSource(this, Uri.parse(uris.get(index)));
            player.setOnPreparedListener(mp -> { prepared=true; mp.start(); updateNotification(); });
            player.setOnCompletionListener(mp -> next());
            player.setOnErrorListener((mp,what,extra)->{ next(); return true; });
            startForeground(1, buildNotification()); player.prepareAsync();
        } catch (IOException | SecurityException e) { next(); }
    }
    private void next() { if(uris.isEmpty())return; if(shuffle && uris.size()>1) { int old=index; do { index=(int)(Math.random()*uris.size()); } while(index==old); } else index=(index+1)%uris.size(); playCurrent(); }
    private void previous() { if(uris.isEmpty())return; index=(index-1+uris.size())%uris.size(); playCurrent(); }
    private void releasePlayer() { prepared=false; if(player!=null){ try{player.stop();}catch(Exception ignored){} player.release(); player=null; } }
    private void createChannel() { if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CHANNEL,"Music playback",NotificationManager.IMPORTANCE_LOW); c.setDescription("Playback controls for Quick Player"); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
    private PendingIntent action(String a,int code) { Intent i=new Intent(this,PlaybackService.class); i.setAction(a); int f=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0); return PendingIntent.getService(this,code,i,f); }
    private Notification buildNotification() {
        String title=titles.isEmpty()?"Quick Player":titles.get(index);
        String by=artists.isEmpty()?"Your music":artists.get(index);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(by).setOngoing(player!=null && player.isPlaying()).setOnlyAlertOnce(true)
         .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Previous",action(ACTION_PREVIOUS,2)).build())
         .addAction(new Notification.Action.Builder(player!=null && player.isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,"Play/Pause",action(ACTION_TOGGLE,3)).build())
         .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Next",action(ACTION_NEXT,4)).build());
        return b.build();
    }
    private void updateNotification(){ NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); nm.notify(1,buildNotification()); }
    @Override public void onTaskRemoved(Intent rootIntent) { /* Keep playback alive when the app is swiped away. */ }
    @Override public void onDestroy(){ releasePlayer(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
