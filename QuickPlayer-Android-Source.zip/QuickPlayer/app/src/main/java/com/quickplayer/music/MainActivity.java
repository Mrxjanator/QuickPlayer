package com.quickplayer.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private final ArrayList<String> uris = new ArrayList<>();
    private final ArrayList<String> titles = new ArrayList<>();
    private final ArrayList<String> artists = new ArrayList<>();
    private TextView info, now, artist;
    private Button play;
    private boolean playing = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        info = findViewById(R.id.libraryInfo); now = findViewById(R.id.nowPlaying);
        artist = findViewById(R.id.artist); play = findViewById(R.id.playPause);
        ListView list = findViewById(R.id.songList);
        list.setOnItemClickListener((p,v,pos,id) -> startTrack(pos));
        play.setOnClickListener(v -> {
            if (uris.isEmpty()) return;
            Intent i = new Intent(this, PlaybackService.class);
            i.setAction(PlaybackService.ACTION_TOGGLE);
            startPlaybackService(i);
            playing = !playing; play.setText(playing ? "Ⅱ PAUSE" : "▶ PLAY");
        });
        findViewById(R.id.next).setOnClickListener(v -> command(PlaybackService.ACTION_NEXT));
        findViewById(R.id.previous).setOnClickListener(v -> command(PlaybackService.ACTION_PREVIOUS));
        findViewById(R.id.shuffle).setOnClickListener(v -> {
            if (!uris.isEmpty()) { Intent i = playlistIntent(0); i.setAction(PlaybackService.ACTION_SHUFFLE); startPlaybackService(i); playing=true; play.setText("Ⅱ PAUSE"); }
        });
        if (hasAudioPermission()) scan(); else requestAudioPermission();
    }

    private boolean hasAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, REQ_AUDIO);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_AUDIO);
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == REQ_AUDIO && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) scan();
        else info.setText("Audio access is needed to show your music. You can allow it in app settings.");
    }
    private void scan() {
        uris.clear(); titles.clear(); artists.clear();
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST};
        String selection = null;
        try (Cursor c = getContentResolver().query(collection, projection, selection, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c != null) while (c.moveToNext()) {
                long id = c.getLong(0);
                String title = c.getString(1); String by = c.getString(2);
                uris.add(ContentUris.withAppendedId(collection,id).toString());
                titles.add(title == null ? "Unknown title" : title);
                artists.add(by == null || by.equals("<unknown>") ? "Unknown artist" : by);
            }
        } catch (Exception e) { info.setText("Couldn't scan audio: " + e.getMessage()); }
        ArrayList<String> rows = new ArrayList<>();
        for (int x=0;x<titles.size();x++) rows.add(titles.get(x) + "\n" + artists.get(x));
        listAdapter(rows);
        info.setText(titles.size() + (titles.size()==1 ? " track found" : " tracks found") + " · stored on this phone");
    }
    private void listAdapter(ArrayList<String> rows) {
        ListView list = findViewById(R.id.songList);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1, rows) {
            @Override public View getView(int pos, View convert, android.view.ViewGroup parent) {
                View v = super.getView(pos,convert,parent);
                TextView t1=v.findViewById(android.R.id.text1), t2=v.findViewById(android.R.id.text2);
                String[] bits=rows.get(pos).split("\\n",2);
                t1.setText(bits[0]); t1.setTextColor(0xFFFFFFFF); t1.setTextSize(15);
                t2.setText(bits.length>1?bits[1]:""); t2.setTextColor(0xFF999999); t2.setTextSize(12);
                v.setBackgroundColor(0xFF101010); v.setPadding(8,12,8,12); return v;
            }
        };
        list.setAdapter(adapter);
    }
    private Intent playlistIntent(int index) {
        Intent i = new Intent(this, PlaybackService.class);
        i.putStringArrayListExtra(PlaybackService.EXTRA_URIS, uris);
        i.putStringArrayListExtra(PlaybackService.EXTRA_TITLES, titles);
        i.putStringArrayListExtra(PlaybackService.EXTRA_ARTISTS, artists);
        i.putExtra(PlaybackService.EXTRA_INDEX,index); return i;
    }
    private void startTrack(int pos) {
        Intent i=playlistIntent(pos); i.setAction(PlaybackService.ACTION_PLAY); startPlaybackService(i);
        now.setText(titles.get(pos)); artist.setText(artists.get(pos)); playing=true; play.setText("Ⅱ PAUSE");
    }
    private void command(String action) { Intent i=new Intent(this,PlaybackService.class); i.setAction(action); startPlaybackService(i); }
    private void startPlaybackService(Intent i) {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
}
