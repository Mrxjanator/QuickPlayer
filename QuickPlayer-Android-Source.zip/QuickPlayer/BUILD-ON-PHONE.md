# Build QuickPlayer APK using GitHub Actions (phone-friendly)

This project needs the Android SDK and Gradle to compile. They are not included in the source ZIP.

1. In your phone browser, sign in to https://github.com/ and create a new **private** repository.
2. Upload the contents of this `QuickPlayer` folder to the repository (the `.github/workflows/build-apk.yml` file must be included).
3. Open the repository's **Actions** tab and select **Build QuickPlayer APK**.
4. Tap **Run workflow**. Wait for the run to finish successfully.
5. Open the completed run, scroll to **Artifacts**, and download `QuickPlayer-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`, which you can install on your Android phone.

The workflow builds a debug APK for personal testing. It does not install anything on your phone.
