# Quick Player (Android source project)

A small, offline Android audio player prototype. It reads audio indexed by Android MediaStore, lists tracks, starts playback with one tap, and uses a foreground service so playback can continue after leaving the app or turning the screen off. The service notification has previous, play/pause, and next controls. Shuffle is available in the app.

## Build

Open this folder in Android Studio (current stable version), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK will be under `app/build/outputs/apk/debug/`.

Requirements: Android SDK 35 and Android Gradle Plugin 8.7.3. The project uses the platform MediaPlayer and has no advertising, analytics, login, or network permission.

## Notes

- The app asks for audio-library permission and lists audio indexed by Android MediaStore.
- Playback compatibility depends on the audio formats supported by the Android device.
- This source project has not been compiled or device-tested in this environment because an Android SDK/Gradle installation is not available here.
