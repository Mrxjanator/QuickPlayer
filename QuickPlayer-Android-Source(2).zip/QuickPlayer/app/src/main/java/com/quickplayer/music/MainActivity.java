package com.quickplayer.music;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO=41, REQ_NOTIFICATIONS=42;
    private final ArrayList<String> uris=new ArrayList<>(), titles=new ArrayList<>(), artists=new ArrayList<>(), albumArts=new ArrayList<>();
    private TextView info,now,artist; private Button play; private boolean playing=false;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        info=findViewById(R.id.libraryInfo);now=findViewById(R.id.nowPlaying);artist=findViewById(R.id.artist);play=findViewById(R.id.playPause);
        ListView list=findViewById(R.id.songList);list.setOnItemClickListener((p,v,pos,id)->startTrack(pos));
        play.setOnClickListener(v->{if(uris.isEmpty())return;Intent i=new Intent(this,PlaybackService.class);i.setAction(PlaybackService.ACTION_TOGGLE);startPlaybackService(i);playing=!playing;play.setText(playing?"Ⅱ PAUSE":"▶ PLAY");});
        findViewById(R.id.next).setOnClickListener(v->command(PlaybackService.ACTION_NEXT));findViewById(R.id.previous).setOnClickListener(v->command(PlaybackService.ACTION_PREVIOUS));
        findViewById(R.id.shuffle).setOnClickListener(v->{if(!uris.isEmpty()){Intent i=playlistIntent(0);i.setAction(PlaybackService.ACTION_SHUFFLE);startPlaybackService(i);playing=true;play.setText("Ⅱ PAUSE");}});
        if(hasAudioPermission())scan();else requestAudioPermission();requestNotificationPermission();
    }
    private boolean hasAudioPermission(){if(Build.VERSION.SDK_INT>=33)return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)==PackageManager.PERMISSION_GRANTED;return Build.VERSION.SDK_INT<23||checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
    private void requestAudioPermission(){if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO},REQ_AUDIO);else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQ_AUDIO);}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)scan();else if(r==REQ_AUDIO)info.setText("Audio access is needed to show your music. Allow it in app settings.");}
    private void scan(){uris.clear();titles.clear();artists.clear();albumArts.clear();Uri collection=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM_ID};
        try(Cursor c=getContentResolver().query(collection,projection,null,null,MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC")){if(c!=null)while(c.moveToNext()){
            long id=c.getLong(0),albumId=c.getLong(3);String title=c.getString(1),by=c.getString(2);
            uris.add(ContentUris.withAppendedId(collection,id).toString());titles.add(title==null?"Unknown title":title);artists.add(by==null||by.equals("<unknown>")?"Unknown artist":by);
            albumArts.add(albumId>0?ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"),albumId).toString():"");
        }}catch(Exception e){info.setText("Couldn't scan audio: "+e.getMessage());}
        ListView list=findViewById(R.id.songList);list.setAdapter(new SongAdapter());info.setText(titles.size()+(titles.size()==1?" track found":" tracks found")+" · stored on this phone");
    }
    private class SongAdapter extends android.widget.BaseAdapter{
        public int getCount(){return titles.size();}public Object getItem(int p){return titles.get(p);}public long getItemId(int p){return p;}
        public View getView(int p,View v,android.view.ViewGroup parent){if(v==null)v=getLayoutInflater().inflate(R.layout.song_row,parent,false);
            ImageView image=v.findViewById(R.id.songArtwork);TextView fallback=v.findViewById(R.id.noArtwork);
            image.setImageDrawable(null);fallback.setVisibility(View.VISIBLE);
            try{if(!albumArts.get(p).isEmpty()){image.setImageURI(Uri.parse(albumArts.get(p)));if(image.getDrawable()!=null)fallback.setVisibility(View.GONE);}}catch(Exception ignored){}
            ((TextView)v.findViewById(R.id.songTitle)).setText(titles.get(p));((TextView)v.findViewById(R.id.songArtist)).setText(artists.get(p));return v;
        }
    }
    private Intent playlistIntent(int index){Intent i=new Intent(this,PlaybackService.class);i.putStringArrayListExtra(PlaybackService.EXTRA_URIS,uris);i.putStringArrayListExtra(PlaybackService.EXTRA_TITLES,titles);i.putStringArrayListExtra(PlaybackService.EXTRA_ARTISTS,artists);i.putStringArrayListExtra(PlaybackService.EXTRA_ALBUM_ART,albumArts);i.putExtra(PlaybackService.EXTRA_INDEX,index);return i;}
    private void startTrack(int pos){Intent i=playlistIntent(pos);i.setAction(PlaybackService.ACTION_PLAY);startPlaybackService(i);now.setText(titles.get(pos));artist.setText(artists.get(pos));playing=true;play.setText("Ⅱ PAUSE");}
    private void command(String action){Intent i=new Intent(this,PlaybackService.class);i.setAction(action);startPlaybackService(i);}
    private void startPlaybackService(Intent i){if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
}
