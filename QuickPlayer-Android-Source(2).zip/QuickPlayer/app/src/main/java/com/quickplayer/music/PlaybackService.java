package com.quickplayer.music;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import java.util.ArrayList;

public class PlaybackService extends Service {
    public static final String ACTION_PLAY="qp.PLAY", ACTION_TOGGLE="qp.TOGGLE", ACTION_NEXT="qp.NEXT", ACTION_PREVIOUS="qp.PREV", ACTION_SHUFFLE="qp.SHUFFLE";
    public static final String EXTRA_URIS="uris", EXTRA_TITLES="titles", EXTRA_ARTISTS="artists", EXTRA_ALBUM_ART="albumArt", EXTRA_INDEX="index";
    private static final String CHANNEL="quick_player_playback";
    private ArrayList<String> uris=new ArrayList<>(), titles=new ArrayList<>(), artists=new ArrayList<>(), albumArts=new ArrayList<>();
    private int index=0; private MediaPlayer player; private boolean prepared=false, shuffle=false;
    private MediaSession session;

    @Override public void onCreate() {
        super.onCreate(); createChannel();
        session=new MediaSession(this,"QuickPlayerSession");
        session.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){ togglePlayback(); }
            @Override public void onPause(){ pausePlayback(); }
            @Override public void onSkipToNext(){ next(); }
            @Override public void onSkipToPrevious(){ previous(); }
            @Override public void onStop(){ pausePlayback(); stopForeground(false); }
        });
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS|MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setActive(true);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if (intent==null) return START_STICKY;
        String action=intent.getAction();
        if (ACTION_PLAY.equals(action)||ACTION_SHUFFLE.equals(action)) {
            ArrayList<String> u=intent.getStringArrayListExtra(EXTRA_URIS);
            if(u!=null){uris=u; titles=intent.getStringArrayListExtra(EXTRA_TITLES); artists=intent.getStringArrayListExtra(EXTRA_ARTISTS); albumArts=intent.getStringArrayListExtra(EXTRA_ALBUM_ART); index=intent.getIntExtra(EXTRA_INDEX,0);}
            shuffle=ACTION_SHUFFLE.equals(action); playCurrent();
        } else if(ACTION_TOGGLE.equals(action)) togglePlayback();
        else if(ACTION_NEXT.equals(action)) next();
        else if(ACTION_PREVIOUS.equals(action)) previous();
        return START_STICKY;
    }
    private void togglePlayback(){ if(player==null) playCurrent(); else if(player.isPlaying()) pausePlayback(); else { if(prepared) player.start(); updatePlaybackState(); updateNotification(); } }
    private void pausePlayback(){ if(player!=null&&player.isPlaying()) player.pause(); updatePlaybackState(); updateNotification(); }
    private void playCurrent(){
        if(uris.isEmpty()){stopSelf();return;} if(index<0||index>=uris.size())index=0; releasePlayer();
        try{
            player=new MediaPlayer(); player.setDataSource(this,Uri.parse(uris.get(index)));
            player.setOnPreparedListener(mp->{prepared=true;mp.start();updateMetadata();updatePlaybackState();updateNotification();});
            player.setOnCompletionListener(mp->next()); player.setOnErrorListener((mp,w,e)->{next();return true;});
            startForeground(1,buildNotification()); player.prepareAsync(); updateMetadata(); updatePlaybackState();
        }catch(Exception e){next();}
    }
    private void next(){if(uris.isEmpty())return;if(shuffle&&uris.size()>1){int old=index;do{index=(int)(Math.random()*uris.size());}while(index==old);}else index=(index+1)%uris.size();playCurrent();}
    private void previous(){if(uris.isEmpty())return;index=(index-1+uris.size())%uris.size();playCurrent();}
    private void releasePlayer(){prepared=false;if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}}
    private Bitmap currentArtwork(){try{if(albumArts!=null&&index<albumArts.size()&&albumArts.get(index)!=null&&!albumArts.get(index).isEmpty())return BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(albumArts.get(index))));}catch(Exception ignored){}return null;}
    private void updateMetadata(){if(session==null||titles.isEmpty())return;MediaMetadata.Builder m=new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,titles.get(index)).putString(MediaMetadata.METADATA_KEY_ARTIST,artists!=null&&index<artists.size()?artists.get(index):"Unknown artist");Bitmap art=currentArtwork();if(art!=null)m.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART,art);session.setMetadata(m.build());}
    private void updatePlaybackState(){if(session==null)return;long state=player!=null&&player.isPlaying()?PlaybackState.STATE_PLAYING:(prepared?PlaybackState.STATE_PAUSED:PlaybackState.STATE_BUFFERING);session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_STOP).setState(state,player!=null&&prepared?player.getCurrentPosition():0,player!=null&&player.isPlaying()?1f:0f).build());}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Music playback",NotificationManager.IMPORTANCE_LOW);c.setDescription("Playback controls for Quick Player");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private PendingIntent action(String a,int code){Intent i=new Intent(this,PlaybackService.class);i.setAction(a);return PendingIntent.getService(this,code,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));}
    private Notification buildNotification(){
        String title=titles.isEmpty()?"Quick Player":titles.get(index), by=artists==null||artists.size()<=index?"Your music":artists.get(index);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(by).setOngoing(player!=null&&player.isPlaying()).setOnlyAlertOnce(true)
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,"Previous",action(ACTION_PREVIOUS,2)).build())
          .addAction(new Notification.Action.Builder(player!=null&&player.isPlaying()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,"Play/Pause",action(ACTION_TOGGLE,3)).build())
          .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,"Next",action(ACTION_NEXT,4)).build());
        if(session!=null)b.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));
        Bitmap art=currentArtwork();if(art!=null)b.setLargeIcon(art);
        return b.build();
    }
    private void updateNotification(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.notify(1,buildNotification());}
    @Override public void onTaskRemoved(Intent rootIntent){/* Keep playback alive after the app is swiped away. */}
    @Override public void onDestroy(){releasePlayer();if(session!=null){session.setActive(false);session.release();}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
